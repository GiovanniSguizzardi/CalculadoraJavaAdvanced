import org.example.Conexao;
import org.example.Requisicao;
import org.example.Resposta;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;


public class Cliente {
    static Conexao c;
    static Socket socket;

    public Cliente(){
        try {
            socket = new Socket("localhost", 9600);//localhost = 127.0.0.1
        } catch (IOException e){
            System.out.println("NAO FOI POSSIVEL RESOLVER O HOST...");
        }
    }

    public static void main(String[] args) throws IOException{
        try {
            new Cliente();
            float op1, op2;
            char oper;
            Scanner in = new Scanner(System.in);
            System.out.printf("[ CALCULADORA DISTRIBUIDA ]\n\r");
            System.out.println("DIGITE O 1º NUMERO");
            op1 = in.nextFloat();
            System.out.println("DIGITE O 2º NUMERO");
            op2 = in.nextFloat();
            System.out.println("ESCOLHA A OPERACAO");
            System.out.println("(+)soma (-)subtracao (*)multiplicacao (%)divisao ");
            oper = in.next().charAt(0);

            Requisicao msqReq = new Requisicao(op1, op2, oper);
            c.send(socket, msqReq);
            Resposta msgReq = (Resposta) c.receive(socket);
            switch (msgReq.getStatus()) {
                case 0:
                    System.out.println("RESULTADO =  " + msgReq.getResult());
                    break;
                case 1:
                    System.out.printf("OPERACAO NAO IMPLEMENTADA");
                    break;
                default:
                    System.out.println("DIVISAO POR ZERO");
                    break;
            }
        }catch (Exception e) {
            System.out.println("problema ao fechar o socket ");
        } finally {
            socket.close();
            }
        }
    }