package org.example;

public interface Serializable {
}
