package org.example;

import java.net.ServerSocket;
import java.net.Socket;

import static javax.management.remote.JMXConnectorFactory.connect;

public class Servidor {
    static ServerSocket serverSocket;
    static Socket client_socket;
    static Conexao c;

    public Servidor() {
        try {
            serverSocket = new ServerSocket( 9600);
            System.out.println("[ Calculadora distribuida no ar!!! ]");
            System.out.println("[...] Aguardando cliente fazer requisição");
        } catch (Exception e) {
            System.out.println("[ERROR] Não criei o servidor socket...");
        }
    }

    public static void main(String args[]) {
        Requisicao msgReq;
        Resposta msgRep;
        int visita = 0;
        new Servidor();

        while(true) {
            if ( connect() ) {
                msgReq = (Requisicao) c.receive(client_socket);
                char op = msgReq.getOperacao();
                System.out.println("[Resultado] Operação feita pelo Cliente = " + op);
                msgRep = new Resposta();

                switch (op){
                    case '+':
                        msgRep.setStatus(0);
                        msgRep.setResult( msgReq.getOp1() + msgReq.getOp2() );
                        break;

                    case '-':
                        msgRep.setStatus(0);
                        msgRep.setResult( msgReq.getOp1() - msgReq.getOp2() );
                        break;

                    case '*':
                        msgRep.setStatus(0);
                        msgRep.setResult( msgReq.getOp1() * msgReq.getOp2() );
                        break;

                    case '/':
                        if (msgReq.getOp2() == 0.0F) {
                            msgRep.setStatus(2);
                        } else {
                            msgRep.setStatus(0);
                            msgRep.setResult(msgReq.getOp1() / msgReq.getOp2());
                        }
                        break;
                    default:
                        msgRep.setStatus(1);
                        break;
                }
                c.send(client_socket, msgRep);
            } else {
                try {
                    serverSocket.close();
                    break;
                } catch (Exception e) {
                    System.out.println("[...] Não desconectei");
                }
            }
        }
    }

    static boolean connect() {
        boolean ret;
        try {
            client_socket = serverSocket.accept();
            return true;
        } catch (Exception e) {
            System.out.println("[...] Erro de Connect" + e.getMessage());
            return false;
        }
    }
}

